# Civic Intelligence Engine – PMAY Urban Housing

This project converts PMAY-Urban housing policy rules into structured data and applies machine learning models to explain and recommend housing schemes.

## Data Sources
- pmay-urban.gov.in
- myscheme.gov.in
- pib.gov.in

## Models Used
- Decision Tree for subsidy classification
- KNN for scheme recommendation

## Localized Focus
India with selected state examples (Telangana, Andhra Pradesh)
